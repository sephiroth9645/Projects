﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.IO;
using System.Media;
using Microsoft.VisualBasic;

namespace TypingCrazy
{
    public partial class Typingform : Form
    {
        private int next = -1;
        private Button t;
        private int se;
        private int correct;
        private int incorrect;
        private SoundPlayer sp;

        private String message;
        private String defaultValue;
        private String name;
        private String title;

        private double average;
 

        public Typingform()
        {
            InitializeComponent();
        }

        private void bntf2_Click(object sender, EventArgs e)
        {

        }

        private void bntesc_Click(object sender, EventArgs e)
        {
             
        }

        private void richTextBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {
             
        }

        private void textBox1_KeyPress(object sender, KeyPressEventArgs e)
        {
            
            char key = e.KeyChar;
            char[] c = txtbox.Text.ToCharArray();           
            next++;
            //check number keys and letters keys
            //highligh character and button
            for (int i = 0; i < this.panel1.Controls.Count; i++)
            {
                if (this.panel1.Controls[i].Name.Substring(0, 4).ToLower().CompareTo("bnt" + key.ToString().ToLower()) == 0 && this.panel1.Controls[i].Name.Length<=4)
                    highligh((Button)this.panel1.Controls[i],c, next, key);
            }

            //check symbols: ',~!, @ #, $ %,...

            if ((int)key == 33) highligh(bnt1, c, next, key);
            if ((int)key == 64) highligh(bnt2, c, next, key);
            if ((int)key == 35) highligh(bnt3, c, next, key);
            if ((int)key == 36) highligh(bnt4, c, next, key);
            if ((int)key == 37) highligh(bnt5, c, next, key);
            if ((int)key == 94) highligh(bnt6, c, next, key);
            if ((int)key == 38) highligh(bnt7, c, next, key);
            if ((int)key == 42) highligh(bnt8, c, next, key);
            if ((int)key == 40) highligh(bnt9, c, next, key);
            if ((int)key == 41) highligh(bnt0, c, next, key);
           
           
            if ((int)key == 126 || (int)key == 96) highligh(bntaccent, c, next, key);
            
            if ((int)key == 123 || (int)key == 91) highligh(bntopenbrace, c, next, key);
            if ((int)key == 125 || (int)key == 93) highligh(bntclosebrace, c, next, key);
            if ((int)key == 58 || (int)key == 59) highligh(bntsemi, c, next, key);
            if ((int)key == 34 || (int)key == 39) highligh(bntquote, c, next, key);
            if ((int)key == 60 || (int)key == 44) highligh(bntcomma, c, next, key);
            if ((int)key == 62 || (int)key == 46) highligh(bntpoint, c, next, key);
            if ((int)key == 63 || (int)key == 47) highligh(bntbackslash, c, next, key);
            if ((int)key == 124 || (int)key == 92) highligh(bntforwardslash, c, next, key);
            if ((int)key == 95 || (int)key ==45) highligh(bntminus, c, next, key);
            if ((int)key == 43 || (int)key == 61) highligh(bntequal, c, next, key);

            //check spacebar and enter keys
            if ((int)key == 32) highligh(bntspacebar, c, next, key);
            if ((int)key == 13) highligh(bntenter, c, next, key);
            
            //stop timer when the number of keypesses equal to the number of letters displayed in the box
            if (c.Length == next + 1)
            {
                txtcorrect.Text = correct.ToString();
                txtincorrect.Text = incorrect.ToString();

                double correctTyped = Convert.ToDouble(correct.ToString());
                double wpm = 5;
                String time = timer1.ToString();
                double timer = Convert.ToDouble(txttime.Text);
                double average = Math.Round(correctTyped / wpm / timer, 2);

                average *= 100;

                double pCorrect = Convert.ToDouble(correct.ToString());
                double pIncorrect = Convert.ToDouble(incorrect.ToString());

                double newAverage = pCorrect + pIncorrect;

                double totalAverage = Math.Round((pCorrect / newAverage) * 100, 2);
                try
                {
                    lblWPM.Text = average.ToString() + "WPM";
                    lblAverage.Text = totalAverage.ToString() + "%";
                }
                catch(Exception E)
                {
                    MessageBox.Show("Error at: " + E);
                }
                timer1.Stop();
            }
        }

        private void Form1_Load(object sender, EventArgs e)
        {   /*intialize controls and variables
            txtbox.BackColor = Color.LightSkyBlue;
            textBox1.TabIndex = 0;
            se = 0;
            correct = 0;
            incorrect = 0;
            //load text
            txtbox.Text = loadtext("lesson1.txt");
            //start timer
            timer1.Interval = 1000;           
            timer1.Start();
            //sound object
            sp = new SoundPlayer(@"/BUZZ.WAV");
            */
        }

        private void menuSelect_Click(object sender, EventArgs e)
        {
            
        }

        private void label2_Click(object sender, EventArgs e)
        {

        }
        private void highligh(Button con,char[] c, int next, char key)
        {

            try
            {
                t.BackColor = Color.White;
            }catch (Exception e) { }

            try
            {

                if ((int)key == (int)c[next])
                {

                    //check(key, Color.Green);
                    con.BackColor = Color.Green;
                    t = con;
                    txtbox.SelectionStart = next;
                    txtbox.SelectionLength = 1;
                    txtbox.SelectionColor = Color.Green;
                    correct++;
                }
                else if ((int)key == 13 && (int)c[next] == 10)
                {
                    bntenter.BackColor = Color.Green;
                    t = bntenter;
                    correct++;
                }
                else
                {
                    //check(key, Color.Red);
                    con.BackColor = Color.Red;
                    t = con;
                    txtbox.SelectionStart = next;
                    txtbox.SelectionLength = 1;
                    txtbox.SelectionColor = Color.Red;
                    incorrect++;
                    SystemSounds.Exclamation.Play()  ;     
                }

            }
            catch (Exception e) { }
        }


        private void label22_Click(object sender, EventArgs e)
        {

        }

        private void minimizeToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.WindowState = FormWindowState.Minimized;
        }

        private void timer1_Tick(object sender, EventArgs e)
        {

            se += 1;
            txttime.Text = se.ToString() ;
            
        }


        private string loadtext(string filename)
        {
            FileStream fs = new FileStream(filename, FileMode.Open, FileAccess.Read); 
            StreamReader fr = new StreamReader(fs);

            string content = fr.ReadToEnd();

            //close FileStream object
            fs.Close();
            return content;

        }

        private void reload(string filename)
        {
            try
            {
                t.BackColor = Color.White;
            }
            catch (Exception ex) { }
            next = -1;
            se = 0;
            correct = 0;
            incorrect = 0;
            txtincorrect.Text = "";
            txtcorrect.Text = "";
            textBox1.Focus();
            txtbox.Clear();
            txtbox.Text = loadtext(filename);
        }

        private void bnt0_Click(object sender, EventArgs e)
        {

        }

        private void bnt3_Click(object sender, EventArgs e)
        {

        }

        private void bntaccent_Click(object sender, EventArgs e)
        {

        }

        private void lblaccent_Click(object sender, EventArgs e)
        {

        }

        private void panel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void bntctrlright_Click(object sender, EventArgs e)
        {

        }

        private void bntaltright_Click(object sender, EventArgs e)
        {

        }

        private void bntspacebar_Click(object sender, EventArgs e)
        {

        }

        private void bntaltleft_Click(object sender, EventArgs e)
        {

        }

        private void bntfn_Click(object sender, EventArgs e)
        {

        }

        private void bntctrl_Click(object sender, EventArgs e)
        {

        }

        private void bntshiftright_Click(object sender, EventArgs e)
        {

        }

        private void lblbackslash_Click(object sender, EventArgs e)
        {

        }

        private void bntbackslash_Click(object sender, EventArgs e)
        {

        }

        private void bntpoint_Click(object sender, EventArgs e)
        {

        }

        private void lblcomma_Click(object sender, EventArgs e)
        {

        }

        private void bntcomma_Click(object sender, EventArgs e)
        {

        }

        private void bntm_Click(object sender, EventArgs e)
        {

        }

        private void bntn_Click(object sender, EventArgs e)
        {

        }

        private void bntb_Click(object sender, EventArgs e)
        {

        }

        private void bntv_Click(object sender, EventArgs e)
        {

        }

        private void bntc_Click(object sender, EventArgs e)
        {

        }

        private void bntx_Click(object sender, EventArgs e)
        {

        }

        private void bntz_Click(object sender, EventArgs e)
        {

        }

        private void bntshift_Click(object sender, EventArgs e)
        {

        }

        private void bntenter_Click(object sender, EventArgs e)
        {

        }

        private void lblquote_Click(object sender, EventArgs e)
        {

        }

        private void bntquote_Click(object sender, EventArgs e)
        {

        }

        private void lblsemi_Click(object sender, EventArgs e)
        {

        }

        private void bntsemi_Click(object sender, EventArgs e)
        {

        }

        private void bntl_Click(object sender, EventArgs e)
        {

        }

        private void bntk_Click(object sender, EventArgs e)
        {

        }

        private void bntj_Click(object sender, EventArgs e)
        {

        }

        private void bnth_Click(object sender, EventArgs e)
        {

        }

        private void bntg_Click(object sender, EventArgs e)
        {

        }

        private void bntf_Click(object sender, EventArgs e)
        {

        }

        private void bntd_Click(object sender, EventArgs e)
        {

        }

        private void bnts_Click(object sender, EventArgs e)
        {

        }

        private void bnta_Click(object sender, EventArgs e)
        {

        }

        private void bntcaps_Click(object sender, EventArgs e)
        {

        }

        private void label18_Click(object sender, EventArgs e)
        {

        }

        private void bntforwardslash_Click(object sender, EventArgs e)
        {

        }

        private void lblclosebrace_Click(object sender, EventArgs e)
        {

        }

        private void bntclosebrace_Click(object sender, EventArgs e)
        {

        }

        private void lblopenbrace_Click(object sender, EventArgs e)
        {

        }

        private void bntopenbrace_Click(object sender, EventArgs e)
        {

        }

        private void bntp_Click(object sender, EventArgs e)
        {

        }

        private void bnto_Click(object sender, EventArgs e)
        {

        }

        private void bnti_Click(object sender, EventArgs e)
        {

        }

        private void bntu_Click(object sender, EventArgs e)
        {

        }

        private void bnty_Click(object sender, EventArgs e)
        {

        }

        private void bntt_Click(object sender, EventArgs e)
        {

        }

        private void bntr_Click(object sender, EventArgs e)
        {

        }

        private void bnte_Click(object sender, EventArgs e)
        {

        }

        private void bntw_Click(object sender, EventArgs e)
        {

        }

        private void bntq_Click(object sender, EventArgs e)
        {

        }

        private void bnttab_Click(object sender, EventArgs e)
        {

        }

        private void bntbackspace_Click(object sender, EventArgs e)
        {

        }

        private void lblequal_Click(object sender, EventArgs e)
        {

        }

        private void bntequal_Click(object sender, EventArgs e)
        {

        }

        private void lblminus_Click(object sender, EventArgs e)
        {

        }

        private void bntminus_Click(object sender, EventArgs e)
        {

        }

        private void lbl0_Click(object sender, EventArgs e)
        {

        }

        private void lbl9_Click(object sender, EventArgs e)
        {

        }

        private void bnt9_Click(object sender, EventArgs e)
        {

        }

        private void lbl8_Click(object sender, EventArgs e)
        {

        }

        private void bnt8_Click(object sender, EventArgs e)
        {

        }

        private void lbl7_Click(object sender, EventArgs e)
        {

        }

        private void bnt7_Click(object sender, EventArgs e)
        {

        }

        private void lbl6_Click(object sender, EventArgs e)
        {

        }

        private void bnt6_Click(object sender, EventArgs e)
        {

        }

        private void lbl5_Click(object sender, EventArgs e)
        {

        }

        private void bnt5_Click(object sender, EventArgs e)
        {

        }

        private void lbl4_Click(object sender, EventArgs e)
        {

        }

        private void bnt4_Click(object sender, EventArgs e)
        {

        }

        private void lbl3_Click(object sender, EventArgs e)
        {

        }

        private void lbl2_Click(object sender, EventArgs e)
        {

        }

        private void bnt2_Click(object sender, EventArgs e)
        {

        }

        private void label4_Click(object sender, EventArgs e)
        {

        }

        private void lbl1_Click(object sender, EventArgs e)
        {

        }

        private void bnt1_Click(object sender, EventArgs e)
        {

        }

        private void bntpause_Click(object sender, EventArgs e)
        {

        }

        private void bntdelete_Click(object sender, EventArgs e)
        {

        }

        private void bntinsert_Click(object sender, EventArgs e)
        {

        }

        private void bntnumlk_Click(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {

        }

        private void bntf11_Click(object sender, EventArgs e)
        {

        }

        private void bntf10_Click(object sender, EventArgs e)
        {

        }

        private void bntf9_Click(object sender, EventArgs e)
        {

        }

        private void bntf8_Click(object sender, EventArgs e)
        {

        }

        private void bntf7_Click(object sender, EventArgs e)
        {

        }

        private void bntf6_Click(object sender, EventArgs e)
        {

        }

        private void bntf5_Click(object sender, EventArgs e)
        {

        }

        private void bntf4_Click(object sender, EventArgs e)
        {

        }

        private void bntf3_Click(object sender, EventArgs e)
        {

        }

        private void bntf1_Click(object sender, EventArgs e)
        {

        }

        private void menuStrip1_ItemClicked(object sender, ToolStripItemClickedEventArgs e)
        {

        }

        private void txttime_TextChanged(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void txtcorrect_TextChanged(object sender, EventArgs e)
        {

        }

        private void label5_Click(object sender, EventArgs e)
        {

        }

        private void txtincorrect_TextChanged(object sender, EventArgs e)
        {

        }

        private void lesson1ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            reload("C:/Typing Tutor/lesson1.txt");
            timer1.Interval = 1000;
            timer1.Start();
        }

        private void mnuLesson2_Click(object sender, EventArgs e)
        {
            reload("C:/Typing Tutor/lesson2.txt");
            timer1.Interval = 1000;
            timer1.Start();
        }

        private void mnuName_Click(object sender, EventArgs e)
        {
            message = "Name:";
            title = "Name box";
            defaultValue = " ";
            String name = Interaction.InputBox(message, title, defaultValue, 100, 100);

            if(lblName.Text == " ")
            {
                lblName.Text = defaultValue;
            }
            else if(lblName.Text != " ")
            {
                lblName.Text = name;
            }
            else
            {
                MessageBox.Show("You can't enter any value except your name.");
            }
        }

        private void mnuExit_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void lblAverage_Click(object sender, EventArgs e)
        {

        }
    }
}
